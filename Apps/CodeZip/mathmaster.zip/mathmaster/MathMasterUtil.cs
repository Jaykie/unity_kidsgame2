
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public class MathMasterUtil
{


    public const string STRING_MATH_GAMEBOX_ITEM_ADD = "+";
    public const string STRING_MATH_GAMEBOX_ITEM_MINUS = "-";
    public const string STRING_MATH_GAMEBOX_ITEM_MULTI = "x";
    public const string STRING_MATH_GAMEBOX_ITEM_DIVI = "/";//division

    public const int MATH_GAMEBOX_ITEM_TYPE_NUM = 0;
    public const int MATH_GAMEBOX_ITEM_TYPE_OPERATOR = 1;
    public const int MATH_FORMULATION_NUM_MIN = 3;
    static public int String2Int_Format(string str)
    {
        string str_new = "";
        for (int i = 0; i < str.Length; i++)
        {
            string word = str.Substring(i, 1);
            if (!StringIsNum(word))
            {
                break;
            }
            str_new += word;
        }

        int ret = Common.String2Int(str_new);
        return ret;
    }

    static public string mathFormulationArray2String(List<string> list)
    {
        string str = "";
        foreach (string strtmp in list)
        {
            str += strtmp;
        }
        return str;
    }

    //2+4-2-4 to:array "2","+","4","-","2","-","4"
    static public List<string> mathFormulationString2Array(string str)
    {
        int idx = 0;
        if (Common.BlankString(str))
        {
            return null;
        }
        //Debug.Log("mathFormulationString2Array:");
        List<string> array = new List<string>();
        string word = str.Substring(0, 1);
        //Debug.Log("word:" + word);
        int value = 0;
        if (StringIsNum(word))
        {
            value = String2Int_Format(str);
            string strnum = value.ToString();
            //Debug.Log("array.Add 0 strnum=:" + strnum);
            array.Add(strnum);
        }

        for (int i = 0; i < str.Length; i++)
        {
            word = str.Substring(i, 1);
            if (isMathOperator(word))
            {
                array.Add(word);
                //运算符号后面的数字
                idx = i + 1;
                if (idx < str.Length)
                {
                    string word_next = str.Substring(idx, 1);
                    if (StringIsNum(word_next))
                    {
                        string word_last = str.Substring(i + 1);
                        value = String2Int_Format(word_last);
                        string strnum = value.ToString();
                        //Debug.Log("array.Add strnum=:" + strnum);
                        array.Add(strnum);
                    }
                }

            }
            else if (word == "=")
            {
                //遇到等号退出
                break;

            }

        }


        //加上等号以后的字符串 =
        idx = str.IndexOf("=");
        if (idx >= 0)
        {
            string strtmp = str.Substring(idx);
            array.Add(strtmp);
        }

        return array;
    }

    //添加括号 1+2x3 to:(1+2)x3
    static public string mathFormulationStringFormat(string str)
    {
        string strret = str;
        List<string> arrayStr = mathFormulationString2Array(str);
        if (arrayStr == null)
        {
            return strret;
        }
        int count = arrayStr.Count;

        int index_operator = 0;
        for (int i = 0; i < count; i++)
        {
            string strcur = (string)arrayStr[i];

            if ((index_operator > 0) && ((strcur == STRING_MATH_GAMEBOX_ITEM_MULTI) || (strcur == STRING_MATH_GAMEBOX_ITEM_DIVI)))
            {
                //从第二个运算符为x或／开始

                string strcur_new = ")" + strcur;
                arrayStr[i] = strcur_new;

                //replace head
                string strHead = (string)arrayStr[0];
                string strhead_new = "(" + strHead;
                arrayStr[i] = strhead_new;
            }

            if (isMathOperator(strcur))
            {
                index_operator++;
            }
        }

        strret = "";
        count = arrayStr.Count;
        for (int i = 0; i < count; i++)
        {
            string strcur = (string)arrayStr[i];
            strret += strcur;
        }

        return strret;
    }


    //是否运算符
    static public bool isMathOperator(string str)
    {
        bool ret = false;
        if ((str == STRING_MATH_GAMEBOX_ITEM_ADD) || (str == STRING_MATH_GAMEBOX_ITEM_MULTI) || (str == STRING_MATH_GAMEBOX_ITEM_MINUS) || (str == STRING_MATH_GAMEBOX_ITEM_DIVI))
        {
            ret = true;
        }
        return ret;
    }

    static public bool StringIsNum(string str)
    {
        int v = 0;
        bool ret = int.TryParse(str, out v);
        return ret;
    }
    static public bool isMathFormulationError(List<object> arrayFormulation)
    {
        bool ret = false;
        int type1, type2;
        type1 = 0;
        type2 = 1;
        for (int i = 0; i < arrayFormulation.Count; i++)
        {
            string str = (string)arrayFormulation[i];
            type1 = MATH_GAMEBOX_ITEM_TYPE_NUM;
            if (isMathOperator(str))
            {
                type1 = MATH_GAMEBOX_ITEM_TYPE_OPERATOR;
            }
            if ((i == 0) && (type1 == MATH_GAMEBOX_ITEM_TYPE_OPERATOR))
            {
                //第一个为运算符
                ret = true;
                break;
            }


            int index_next = i + 1;
            if (index_next < arrayFormulation.Count)
            {
                str = (string)arrayFormulation[index_next];
                type2 = MATH_GAMEBOX_ITEM_TYPE_NUM;
                if (isMathOperator(str))
                {
                    type2 = MATH_GAMEBOX_ITEM_TYPE_OPERATOR;
                }


                if (type1 == type2)
                {
                    ret = true;
                    break;
                }
            }
        }

        return ret;
    }

    static public int mathFormulation(int num1, int num2, string formulation)
    {
        int ret = 0;
        if (formulation == STRING_MATH_GAMEBOX_ITEM_ADD)
        {
            ret = num1 + num2;
        }

        if (formulation == STRING_MATH_GAMEBOX_ITEM_MINUS)
        {
            ret = num1 - num2;
        }

        if (formulation == STRING_MATH_GAMEBOX_ITEM_MULTI)
        {
            ret = num1 * num2;
        }

        if (formulation == STRING_MATH_GAMEBOX_ITEM_DIVI)
        {
            ret = num1 / num2;
        }


        return ret;

    }

    //计算数学公式结果
    static public int mathFormulationForString(List<object> array)
    {
        int ret = -1;
        int num1, num2, indexpre, indexnext, indexcur;
        bool isMathNext = false;
        for (int i = 0; i < array.Count; i++)
        {
            string str = (string)array[i];

            if (isMathOperator(str))
            {
                indexcur = i;
                string str_formulation = str;
                indexpre = i - 1;
                if (indexpre >= 0)
                {
                    str = (string)array[indexpre];
                    num1 = String2Int_Format(str);

                    indexnext = i + 1;
                    if (indexnext < array.Count)
                    {
                        str = (string)array[indexnext];
                        num2 = String2Int_Format(str);
                        ret = mathFormulation(num1, num2, str_formulation);
                        string strRet = ret.ToString();
                        array[indexnext] = strRet;
                        array.RemoveAt(indexpre);
                        array.RemoveAt(indexpre);//indexcur 
                        if (array.Count >= MATH_FORMULATION_NUM_MIN)
                        {
                            isMathNext = true;

                            break;
                        }

                    }

                }


            }
        }

        if (isMathNext)
        {
            ret = mathFormulationForString(array);
        }

        return ret;

    }


    //从string里过滤出运算符string如 2—4+2x3 to -+x
    static public string stringFilterOperator(string str)
    {
        string strret = "";

        for (int i = 0; i < str.Length; i++)
        {
            string word = str.Substring(i, 1);
            if (isMathOperator(word))
            {
                strret += word;
            }

        }
        return strret;
    }

    //获取运算正确的式子
    static public bool isFindMathFormulation(string str, List<object> listFormulation, out int indexFind)
    {
        bool ret = false;
        string strCur = stringFilterOperator(str);
        int idx = 0;
        indexFind = 0;
        foreach (List<string> listStr in listFormulation)
        {
            string strInlist = stringFilterOperator(mathFormulationArray2String(listStr));
            if (strCur == strInlist)
            {
                ret = true;
                indexFind = idx;
                break;
            }
            idx++;
        }
        return ret;
    }

}

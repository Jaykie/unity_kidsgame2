﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KaZhuLeViewController : PopViewController
{

    UIKaZhuLeController uiControllerPrefab;
    UIKaZhuLeController uiController;


    static private KaZhuLeViewController _main = null;
    public static KaZhuLeViewController main
    {
        get
        {
            if (_main == null)
            {
                _main = new KaZhuLeViewController(); 
                _main.Init();
            }
            return _main;
        }
    }

    void Init()
    { 
        GameObject obj = PrefabCache.main.Load(AppRes.PREFAB_UIKaZhuLeController);
        uiControllerPrefab = obj.GetComponent<UIKaZhuLeController>();
    }

    public override void ViewDidLoad()
    { 
        base.ViewDidLoad();
        CreateUI();
    } 
    public void CreateUI()
    {
        uiController = (UIKaZhuLeController)GameObject.Instantiate(uiControllerPrefab);
        uiController.SetController(this);
        ViewControllerManager.ClonePrefabRectTransform(uiControllerPrefab.gameObject, uiController.gameObject);
    }
}

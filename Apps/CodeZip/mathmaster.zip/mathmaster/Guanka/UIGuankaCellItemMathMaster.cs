﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UIGuankaCellItemMathMaster : UICellItemBase
{
    public Image imageBg;
    public Image imageBgLock;
    public Image imageIconGold;
    public Text textTitle;
    public Text textDetail;
    public Text textGold;
    public UIGuankaItemIconMathMaster uiGuankaItemIcon;

    public override void UpdateItem(List<object> list)
    {
        Debug.Log("UIGuankaCellItemMathMaster UpdateItem");
        int row = 3;
        int col = 3;
        textTitle.text = Language.game.GetString("GUANKA_TITLE" + index);
        uiGuankaItemIcon.row = row;
        uiGuankaItemIcon.col = col;
        textDetail.text = row.ToString() + "x" + col.ToString();
        uiGuankaItemIcon.UpdateItem();
        imageBgLock.gameObject.SetActive(false);
        if (index > (GameManager.gameLevelFinish + 1))
        {
            if (!Application.isEditor)
            {
                imageBgLock.gameObject.SetActive(true);
            }

        }


        int step_gold = AppRes.GOLD_GUANKA_STEP;//5
        int idx = index;
        imageIconGold.gameObject.SetActive(false);
        textGold.gameObject.SetActive(false);
        if ((idx >= step_gold) && (idx % step_gold == 0))
        {
            imageIconGold.gameObject.SetActive(true);
            textGold.gameObject.SetActive(true);
        }
        textGold.text = "+" + AppRes.GOLD_GUANKA.ToString();

        //TextureUtil.UpdateImageTexture(imageBg,AppRes.IMAGE_GUANKA_CELL_BG,false);
    }
    public override bool IsLock()
    {
        return imageBgLock.gameObject.activeSelf;
    }

}

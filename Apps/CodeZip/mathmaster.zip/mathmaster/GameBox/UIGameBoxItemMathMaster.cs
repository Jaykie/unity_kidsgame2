using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
public class UIGameBoxItemMathMaster : UIView
{

    public GameObject objContent;
    public GameObject objSpriteBg;
    public GameObject objText;

    public int index;
    public int indexRow;//固定不变的row
    public int indexRowDisp;//实际位置显示的row
    public int indexCol;//固定不变的col
    public int indexColDisp;//实际位置显示的col
    public Vector3 posNormal;
    public string strItem;
    public bool isTouchSel = false;//选中
    ItemStatus itemStatus;
    static public Texture2D texNormal;
    static public Texture2D texAnimation;
    static public Texture2D texSel;
    static public Texture2D texError; 

    public enum ItemStatus
    {
        NORMAL = 0,
        SEL,
        ANIMATION,
        ERROR
    }

    void LoadRes()
    {
        texNormal = TextureCache.main.Load(AppRes.IMAGE_ITEM_PIC_NORMAL);
        texAnimation = TextureCache.main.Load(AppRes.IMAGE_ITEM_PIC_ANIMATION);
        texSel = TextureCache.main.Load(AppRes.IMAGE_ITEM_PIC_SEL);
        texError = TextureCache.main.Load(AppRes.IMAGE_ITEM_PIC_ERROR);
 
    }
    public void UpdateItem(MathMasterItemInfo info)
    {
        LoadRes();
        strItem = info.listBox[index];
        TextMesh textMesh = objText.GetComponent<TextMesh>();
        textMesh.text = strItem;

        UpdateItemStatus(ItemStatus.NORMAL);
        isTouchSel = false;
        // if (Common.String2Int(strItem) < 0)
        // {
        //     this.gameObject.SetActive(false);
        // }

        BestFitTextMesh();
    }
    void BestFitTextMesh()
    {
        Bounds boundImage = objSpriteBg.GetComponent<SpriteRenderer>().bounds;
        Bounds bound = objText.GetComponent<MeshRenderer>().bounds;
        RectTransform rctran = this.GetComponent<RectTransform>();
        float ratio = 0;
        if (strItem.Length == 1)
        {
            ratio = 0.3f;
        }
        else if (strItem.Length == 2)
        {
            ratio = 0.6f;
        }
        else if (strItem.Length == 3)
        {
            ratio = 0.8f;
        }
        else if (strItem.Length == 4)
        {
            ratio = 0.9f;
        }
        else
        {
            ratio = 1f;
        }
        float w_disp = boundImage.size.x * ratio;
        float w_content = bound.size.x / objText.transform.localScale.x;
        float scale = w_disp / w_content;
        objText.transform.localScale = new Vector3(scale, scale, 1f);
    }

    public void UpdateItemStatus(ItemStatus st)
    {
        itemStatus = st;
        Texture2D tex = null;
        switch (st)
        {
            case ItemStatus.NORMAL:
                tex = texNormal;
                break;

            case ItemStatus.SEL:
                tex = texSel;

                break;
            case ItemStatus.ANIMATION:
                tex = texAnimation;

                break;

            case ItemStatus.ERROR:
                tex = texError;

                break;

            default:
                break;
        }
        Sprite sp = LoadTexture.CreateSprieFromTex(tex);
        SpriteRenderer render = objSpriteBg.GetComponent<SpriteRenderer>();
        render.sprite = sp;
        {
            RectTransform rctran = this.GetComponent<RectTransform>();
            float w = render.size.x;//rectTransform.rect.width;
            float h = render.size.y;//rectTransform.rect.height;

            float scalex = rctran.rect.width / w;
            float scaley = rctran.rect.height / h;
            float scale = Mathf.Min(scalex, scaley) * 0.9f;
            objSpriteBg.transform.localScale = new Vector3(scale, scale, 1.0f);

        }

    }

    //出现动画
    public void RunActionShow()
    {
        if (!this.gameObject.activeSelf)
        {
            return;
        }
        float delaytime = 0.1f * indexRow;
        iTween.MoveTo(this.gameObject, iTween.Hash("islocal", true, "position", posNormal, "time", 0.5f, "delay", delaytime, "easeType", iTween.EaseType.easeInSine));

    }


    public void RunActionError()
    {
        ////Blink* Blink::create(float duration, int blinks)
        //blinks 每秒闪烁多少次
        //Blink::create(0.6,3),

        UpdateItemStatus(ItemStatus.ERROR);
        ActionBlink actionBlink = this.gameObject.AddComponent<ActionBlink>();
        actionBlink.duration = 2f;
        actionBlink.target = objContent;
        actionBlink.callbackComplete = OnActionErrorComplete;
        actionBlink.Run();
    }

    public void OnActionErrorComplete(GameObject obj)
    {
        UpdateItemStatus(ItemStatus.NORMAL);
    }


    //相当于touchDown
    public void OnPointerDown(PointerEventData eventData)
    {
        Debug.Log("OnPointerDown POS= " + eventData.position + " index=" + index);

    }
    //相当于touchUp
    public void OnPointerUp(PointerEventData eventData)
    {

    }
    //相当于touchMove
    public void OnDrag(PointerEventData eventData)
    {

    }



}

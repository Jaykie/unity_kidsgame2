using System.Collections;
using System.Collections.Generic;
using LitJson;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
/*
参考游戏： Math Academy
https://itunes.apple.com/cn/app/id1001897231
 */
public class MathMasterItemInfo : ItemInfo
{
    public List<object> listFormulation;//公式
    public List<string> listBox;//数字显示

}
public class GameMathMaster : GameBase
{
    public GameObject objTopbar;
    public Image imageTopbar;
    public Text textTitle;

    public UIGameBoxMathMaster uiGameBox;
    public UIMathFormulation uiFormulation;

    public UITipsBarMathMaster uiTipsBar;
    public UIGameFinish uiGameFinish;

    //prefab
    static public UIGameBoxItemMathMaster uiGameBoxItemPrefab;
    static public UIGameBoxMathMaster uiGameBoxPrefab;


    float barHeightCanvas = 160;
    float adBannerHeightCanvas = 0;
    /// <summary>
    /// Awake is called when the script instance is being loaded.
    /// </summary>
    void Awake()
    {
        InitBg();

        uiGameBox = (UIGameBoxMathMaster)GameObject.Instantiate(uiGameBoxPrefab);
        uiGameBox.transform.parent = AppSceneBase.main.objMainWorld.transform;
        uiGameBox.callbackDisplay = OnDisplayMathFormulation;
        uiGameBox.callbackFinish = OnMathFormulationFinish;

        uiTipsBar.callbackClick = OnUITipsBarMathMasterClick;
        uiGameFinish.gameObject.SetActive(false);
 
        LayoutChild();

    }
    /// <summary>
    /// Start is called on the frame when a script is enabled just before
    /// any of the Update methods is called the first time.
    /// </summary>
    void Start()
    {
        uiTipsBar.UpdateGold(Common.gold);

        LayoutChild();

        //LayoutChild 必须在前面执行
        UpdateGuankaLevel(GameManager.gameLevel);

        ShowHowToPlay();
        float delaytime = 0.1f * 10;
        Invoke("OnUIDidFinish", delaytime);
    }
    public override void LoadPrefab()
    {
        {
            GameObject obj = PrefabCache.main.Load("App/Prefab/UIGameBoxItemMathMaster");
            if (obj != null)
            {
                uiGameBoxItemPrefab = obj.GetComponent<UIGameBoxItemMathMaster>();
            }
        }
        {
            GameObject obj = PrefabCache.main.Load("App/Prefab/UIGameBoxMathMaster");
            if (obj != null)
            {
                uiGameBoxPrefab = obj.GetComponent<UIGameBoxMathMaster>();
            }
        }

    }
    void LayoutChild()
    {
        float x, y, w, h;

        Vector2 sizeCanvas = this.frame.size;
        if (sizeCanvas.x <= 0)
        {
            return;
        }
        LayoutChildBase();
        Debug.Log("sizeCanvas=" + sizeCanvas);
        Camera cam = AppSceneBase.main.mainCamera;
        RectTransform rctranFormulation = uiFormulation.GetComponent<RectTransform>();
        RectTransform rctranBox = uiGameBox.GetComponent<RectTransform>();
        RectTransform rctranTips = uiTipsBar.GetComponent<RectTransform>();
        //RectTransform rctranMainWorld = AppSceneBase.main.objMainWorld.GetComponent<RectTransform>();
        float box_ratio = 0.9f;
        if (Device.isLandscape)
        {

            w = sizeCanvas.x / 4;
            h = sizeCanvas.y - barHeightCanvas * 2 - adBannerHeightCanvas;
            rctranFormulation.sizeDelta = new Vector2(w, h);
            x = -sizeCanvas.x / 2 + w / 2;
            y = sizeCanvas.y / 2 - barHeightCanvas - h / 2;
            rctranFormulation.anchoredPosition = new Vector2(x, y);

            //box
            float rc_h = frameMainWorld.height - Common.CanvasToWorldHeight(cam, AppSceneBase.main.sizeCanvas, barHeightCanvas * 2);
            float rc_w = frameMainWorld.width * 3 / 4;
            w = Mathf.Min(rc_w, rc_h) * box_ratio;
            h = w;
            x = frameMainWorld.width / 2 - rc_w / 2;//Common.GetCameraWorldSizeWidth(cam) - rc_w / 2;
            y = 0;//cam.orthographicSize - Common.CanvasToWorldHeight(cam, sizeCanvas, barHeightCanvas) - rc_h / 2;
            rctranBox.sizeDelta = new Vector2(w, h);
            rctranBox.transform.localPosition = new Vector3(x, y, 0);

        }
        else
        {
            w = sizeCanvas.x;
            h = barHeightCanvas * 2;
            rctranFormulation.sizeDelta = new Vector2(w, h);
            y = -sizeCanvas.y / 2 + barHeightCanvas + adBannerHeightCanvas + h / 2;
            x = 0;
            rctranFormulation.anchoredPosition = new Vector2(x, y);

            //box
            float rc_h = frameMainWorld.height - Common.CanvasToWorldHeight(cam, AppSceneBase.main.sizeCanvas, barHeightCanvas * 4);
            float rc_w = frameMainWorld.width;
            w = Mathf.Min(rc_w, rc_h) * box_ratio;
            h = w;
            y = frameMainWorld.height / 2 - Common.CanvasToWorldHeight(cam, AppSceneBase.main.sizeCanvas, barHeightCanvas) - rc_h / 2;
            x = 0;
            rctranBox.sizeDelta = new Vector2(w, h);
            rctranBox.transform.localPosition = new Vector3(x, y, 0);
        }


        x = 0;
        y = adBannerHeightCanvas;
        rctranTips.anchoredPosition = new Vector2(x, y);


    }

    public override void UpdateGuankaLevel(int level)
    {
        MathMasterItemInfo info = (MathMasterItemInfo)GetGuankaItemInfo(level);
        uiGameBox.UpdateItem(info);
        uiFormulation.UpdateItem(info);
    }
    public override int GetGuankaTotal()
    {
        ParseGuanka();
        if (listGuanka != null)
        {
            return listGuanka.Count;
        }
        return 0;
    }

    public override void CleanGuankaList()
    {
        if (listGuanka != null)
        {
            listGuanka.Clear();
        }

    }

    public override int ParseGuanka()
    {
        int count = 0;

        if ((listGuanka != null) && (listGuanka.Count != 0))
        {
            return listGuanka.Count;
        }

        listGuanka = new List<object>();
        int idx = GameManager.placeLevel;
        string fileName = Common.GAME_RES_DIR + "/guanka/guanka_list_place" + idx + ".json";
        //FILE_PATH
        string json = FileUtil.ReadStringAsset(fileName);//((TextAsset)Resources.Load(fileName, typeof(TextAsset))).text;
        // Debug.Log("json::"+json);
        JsonData root = JsonMapper.ToObject(json);
        JsonData items = root["items"];
        for (int i = 0; i < items.Count; i++)
        {
            JsonData item = items[i];
            MathMasterItemInfo info = new MathMasterItemInfo();
            info.title = (string)item["title"];
            info.row = Common.String2Int((string)item["row"]);
            info.col = Common.String2Int((string)item["col"]);


            //array formulation
            JsonData jsonArray = item["formulation"];
            info.listFormulation = new List<object>();
            for (int j = 0; j < jsonArray.Count; j++)
            {
                JsonData jsonValueTmp = jsonArray[j];
                string str = (string)jsonValueTmp;
                List<string> listTmp = MathMasterUtil.mathFormulationString2Array(str);
                info.listFormulation.Add(listTmp);
                //info.listFormulation.Add(str);
            }

            //array mathbox
            jsonArray = item["mathbox"];
            info.listBox = new List<string>();
            for (int j = 0; j < jsonArray.Count; j++)
            {
                JsonData jsonValueTmp = jsonArray[j];
                string str = (string)jsonValueTmp;
                info.listBox.Add(str);
            }


            listGuanka.Add(info);
        }

        count = listGuanka.Count;

        Debug.Log("ParseGame::count=" + count);
        return count;
    }



    public void InitBg()
    {
        AppSceneBase.main.ClearMainWorld();
        spriteBg = LoadTexture.CreateSprieFromTex(TextureCache.main.Load(AppRes.IMAGE_GAME_BG));
        objSpriteBg = SpriteUtil.CreateSpriteObj("objSpriteBg", AppSceneBase.main.objMainWorld, spriteBg);

    }
    void ShowHowToPlay()
    {
        string key = "KEY_FIRST_RUN_HOT_TO_PLAY";
        bool isFirst = Common.GetKeyForFirstRun(key);
        if (isFirst)
        {
            HowToPlayViewController.main.Show(null, null);
            Common.SetKeyForFirstRun(key, false);
        }

    }
    void ShowShop()
    {
        ShopViewController.main.Show(null, null);
    }
    void OnGameWin()
    {
        GameManager.gameLevelFinish = GameManager.gameLevel;
        //GameManager.GotoNextLevel();
        uiGameFinish.gameObject.SetActive(true);

        int step_gold = AppRes.GOLD_GUANKA_STEP;//5

        if ((GameManager.gameLevel >= step_gold) && (GameManager.gameLevel % step_gold == 0))

        {
            Common.gold += AppRes.GOLD_GUANKA;
        }
        AdKitCommon.main.ShowAdInsert(100);
    }

    public void OnMathFormulationFinish(bool isAll, string formulation, int idx)
    {

        uiFormulation.OnFormulationFinish(formulation, idx);
        //show game win
        if (isAll)
        {
            OnGameWin();
        }

    }
    void OnDisplayMathFormulation(string str, Color color)
    {

        // std::string strdisplay = mathFormulationStringFormat(str);

        textTitle.text = str;
        textTitle.color = color;

    }
    public void OnUITipsBarMathMasterClick(int idx)
    {
        switch (idx)
        {
            case 0:
                //again
                UpdateGuankaLevel(GameManager.gameLevel);
                break;
            case 1:
                //tips
                uiFormulation.OnTips();
                uiTipsBar.UpdateGold(Common.gold);
                break;
            case 2:
                //gold
                ShowShop();
                break;

        }
    }

}


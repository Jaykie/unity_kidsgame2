﻿using System.Collections;
using System.Collections.Generic;
using Tacticsoft;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class UIHelpController : UIView, ITableViewDataSource
{
    public GameObject objContent;
    public Button btnBack;
    public Text textTitle;
    public UICellItemBase cellItemPrefab;
    public UICellBase cellPrefab;//GuankaItemCell GameObject 
    public TableView tableView;
    public Image imageBoard;
    public Image imageBg;
    public int numRows;
    private int numInstancesCreated = 0;

    private int oneCellNum;
    private int heightCell;
    int totalItem;

    List<object> listItem;

    /// <summary>
    /// Awake is called when the script instance is being loaded.
    /// </summary>
    void Awake()
    {
        LoadPrefab();
        heightCell = 200;
        listItem = new List<object>();
        textTitle.color = AppRes.colorTitle;
        textTitle.text = Language.main.GetString("STRING_GAME_HELP_TITLE");
        //bg 
        TextureUtil.UpdateImageTexture(imageBg, AppRes.IMAGE_COMMON_BG, true);
        {
            ItemInfo info = new ItemInfo();
            info.title = Language.main.GetString("STRING_HOWTOPLAY_TITLE0");
            listItem.Add(info);
        }

        {
            ItemInfo info = new ItemInfo();
            info.title = Language.main.GetString("STRING_HELP_CELL_TITLE1");
            listItem.Add(info);
        }

    }
    void Start()
    {



        Rect rccell = (cellPrefab.transform as RectTransform).rect;
        Rect rctable = (tableView.transform as RectTransform).rect;
        oneCellNum = 1;
        int total = listItem.Count;
        totalItem = total;
        Debug.Log("total:" + total);
        numRows = total / oneCellNum;
        if (total % oneCellNum != 0)
        {
            numRows++;
        }


        tableView.dataSource = this;



        LayOutChild();

        // if(callbackInitUIFinish!=null){
        //     callbackInitUIFinish();
        // }
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyUp(KeyCode.Escape))
        {
            OnClickBtnBack();
        }
    }
    void LoadPrefab()
    {

        {
            GameObject obj = PrefabCache.main.Load(AppCommon.PREFAB_UICELLBASE);
            cellPrefab = obj.GetComponent<UICellBase>();
        }
        {
            GameObject obj = PrefabCache.main.Load("App/Prefab/Help/UIHelpCellItem");
            cellItemPrefab = obj.GetComponent<UICellItemBase>();
        }

    }

    void LayOutChild()
    {
        float x, y, w, h;
        //Vector2 sizeCanvas = ViewControllerManager.sizeCanvas;
        Vector2 sizeCanvas = this.frame.size;
        {
            RectTransform rectTransform = imageBg.GetComponent<RectTransform>();
            float w_image = rectTransform.rect.width;
            float h_image = rectTransform.rect.height;
            print(rectTransform.rect);
            float scalex = sizeCanvas.x / w_image;
            float scaley = sizeCanvas.y / h_image;
            float scale = Mathf.Max(scalex, scaley);
            imageBg.transform.localScale = new Vector3(scale, scale, 1.0f);

        }
        {
            RectTransform rctran = objContent.GetComponent<RectTransform>();
            w = Mathf.Min(this.frame.width, this.frame.height) * 0.8f;
            h = w;
            rctran.sizeDelta = new Vector2(w, h);
        }

    }



    public void OnClickBtnBack()
    {
        PopViewController pop = (PopViewController)this.controller;
        if (pop != null)
        {
            pop.Close();
        }

    }
    public void OnCellItemDidClick(UICellItemBase item)
    {
        switch (item.index)
        {
            case 0:
                HowToPlayViewController.main.Show(null,null);
                break;
            case 1:
                KaZhuLeViewController.main.Show(null,null);
                break;

        }

        OnClickBtnBack();

    }


    #region ITableViewDataSource

    //Will be called by the TableView to know how many rows are in this table
    public int GetNumberOfRowsForTableView(TableView tableView)
    {
        return numRows;
    }

    //Will be called by the TableView to know what is the height of each row
    public float GetHeightForRowInTableView(TableView tableView, int row)
    {
        return heightCell;
        //return (cellPrefab.transform as RectTransform).rect.height;
    }

    //Will be called by the TableView when a cell needs to be created for display
    public TableViewCell GetCellForRowInTableView(TableView tableView, int row)
    {
        UICellBase cell = tableView.GetReusableCell(cellPrefab.reuseIdentifier) as UICellBase;
        if (cell == null)
        {
            cell = (UICellBase)GameObject.Instantiate(cellPrefab);
            cell.name = "UICellBase" + (++numInstancesCreated).ToString();
            Rect rccell = (cellPrefab.transform as RectTransform).rect;
            Rect rctable = (tableView.transform as RectTransform).rect;
            Vector2 sizeCell = (cellPrefab.transform as RectTransform).sizeDelta;
            Vector2 sizeTable = (tableView.transform as RectTransform).sizeDelta;
            Vector2 sizeCellNew = sizeCell;
            sizeCellNew.x = rctable.width;

            //  cell.SetCellSize(sizeCellNew);

            // Debug.LogFormat("TableView Cell Add Item:rcell:{0}, sizeCell:{1},rctable:{2},sizeTable:{3}", rccell, sizeCell, rctable, sizeTable);
            // oneCellNum = (int)(rctable.width / heightCell);
            //int i =0;
            for (int i = 0; i < oneCellNum; i++)
            {
                int itemIndex = row * oneCellNum + i;
                float cell_space = 10;
                UICellItemBase item = (UICellItemBase)GameObject.Instantiate(cellItemPrefab);
                //item.itemDelegate = this;
                Rect rcItem = (item.transform as RectTransform).rect;
                item.width = (rctable.width - cell_space * (oneCellNum - 1)) / oneCellNum;
                item.height = heightCell;
                item.transform.SetParent(cell.transform, false);
                item.index = itemIndex;
                item.totalItem = totalItem;
                item.callbackClick = OnCellItemDidClick;


                cell.AddItem(item);

            }

        }
        cell.totalItem = totalItem;
        cell.oneCellNum = oneCellNum;
        cell.rowIndex = row;
        cell.UpdateItem(listItem);
        return cell;
    }

    #endregion

    #region Table View event handlers

    //Will be called by the TableView when a cell's visibility changed
    public void TableViewCellVisibilityChanged(int row, bool isVisible)
    {

    }

    #endregion



    public void TableViewCellOnClik()
    {
        print("TableViewCellOnClik1111");
    }

}

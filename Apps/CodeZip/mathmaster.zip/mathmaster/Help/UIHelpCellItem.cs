using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UIHelpCellItem : UICellItemBase
{
    public Image imageBg;
    public Image imageArrow;
    public Text textTitle;
    string[] strImageBg = { AppRes.IMAGE_CELL_BG_BLUE, AppRes.IMAGE_CELL_BG_ORINGE, AppRes.IMAGE_CELL_BG_YELLOW };

    public override void UpdateItem(List<object> list)
    {
        ItemInfo info = list[index] as ItemInfo;
        textTitle.text = info.title;
        Vector4 border = AppRes.borderCellSettingBg;
        TextureUtil.UpdateImageTexture(imageBg, strImageBg[index % 3], false, border);
        RectTransform rctran = imageBg.GetComponent<RectTransform>();
        rctran.offsetMax = Vector2.zero;
        rctran.offsetMin = Vector2.zero;
    }
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HelpViewController : PopViewController
{

    UIHelpController uiControllerPrefab;
    UIHelpController uiController;


    static private HelpViewController _main = null;
    public static HelpViewController main
    {
        get
        {
            if (_main == null)
            {
                _main = new HelpViewController(); 
                _main.Init();
            }
            return _main;
        }
    }

    void Init()
    {
         
        string strPrefab = "App/Prefab/Help/UIHelpController"; 
        GameObject obj = (GameObject)Resources.Load(strPrefab);
        uiControllerPrefab = obj.GetComponent<UIHelpController>();
    }

    public override void ViewDidLoad()
    { 
        CreateUI();
    } 
    public void CreateUI()
    {
        uiController = (UIHelpController)GameObject.Instantiate(uiControllerPrefab);
        uiController.SetController(this);
        ViewControllerManager.ClonePrefabRectTransform(uiControllerPrefab.gameObject, uiController.gameObject);
    }
}

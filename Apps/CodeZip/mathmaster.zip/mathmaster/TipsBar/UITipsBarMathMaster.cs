
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public delegate void OnUITipsBarMathMasterClickDelegate(int idx);
public class UITipsBarMathMaster : UIView
{
    public Image imageBg;
    public UITips uiTips;

    public OnUITipsBarMathMasterClickDelegate callbackClick { get; set; }

    /// <summary>
    /// Awake is called when the script instance is being loaded.
    /// </summary>
    void Awake()
    {
        uiTips.callbackClick = OnUITipsClick;
        UpdateGold(Common.gold);
        if ((!AppVersion.appCheckHasFinished) && (!Config.main.isHaveIAP))
        {
            uiTips.gameObject.SetActive(false);
        }
    }

    void Start()
    {
        LayOut();
    }

    public override void LayOut()
    {
        RectTransform rctran = uiTips.GetComponent<RectTransform>();
        Vector2 size = rctran.sizeDelta;
        size.x = this.frame.size.x/2;
        rctran.sizeDelta = size;
        rctran.anchoredPosition = new Vector2(this.frame.width/4-48,0);
        uiTips.LayOut();
        
    }
    public void UpdateGold(int gold)
    {
        uiTips.UpdateGold(gold);
    }
    public void OnClickBtnHelp()
    {
        HelpViewController.main.Show(null, null);
    }

    public void OnUITipsClick(int idx)
    {
        if (callbackClick != null)
        {
            callbackClick(idx);
        }
    }

    public void OnClickBtnAgain()
    {
        OnUITipsClick(0);
    }
}
